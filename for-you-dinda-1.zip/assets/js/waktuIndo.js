const dayID = () => {
  if (day == 1) {
    return 'Senin'
  }
  if (day == 2) {
    return 'Selasa'
  }
  if (day == 3) {
    return 'Rabu'
  }
  if (day == 4) {
    return 'Kamis'
  }
  if (day == 5) {
    return 'Jumat'
  }
  if (day == 6) {
    return 'Sabtu'
  }
  if (day == 7) {
    return 'Minggu'
  }
}
const monthID = () => {
  if (month == 0) {
    return 'Januari'
  }
  if (month == 1) {
    return 'Februari'
  }
  if (month == 2) {
    return 'Maret'
  }
  if (month == 3) {
    return 'April'
  }
  if (month == 4) {
    return 'Mei'
  }
  if (month == 5) {
    return 'Juni'
  }
  if (month == 6) {
    return 'Juli'
  }
  if (month == 7) {
    return 'Agustus'
  }
  if (month == 8) {
    return 'September'
  }
  if (month == 9) {
    return 'Oktober'
  }
  if (month == 10) {
    return 'November'
  }
  if (month == 11) {
    return 'Desember'
  }
}